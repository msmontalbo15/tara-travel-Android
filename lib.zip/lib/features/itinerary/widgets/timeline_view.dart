import 'package:flutter/material.dart';
import '../../../core/models/itinerary_model.dart';
import '../../../core/theme/app_colors.dart';

/// A horizontal 24-hour Gantt/timeline view for an [ItineraryDay].
/// Each stop block is rendered at its [ItineraryStop.startTime]–[ItineraryStop.endTime].
/// Stops without a time are shown in a "no time" row at the top.
class TimelineView extends StatelessWidget {
  final ItineraryDay day;
  final void Function(ItineraryStop stop) onStopTap;

  const TimelineView({super.key, required this.day, required this.onStopTap});

  static const double _hourWidth = 80.0;
  static const double _rowHeight = 56.0;
  static const double _headerHeight = 28.0;

  @override
  Widget build(BuildContext context) {
    final timedStops = day.stops.where((s) => s.startTime != null && s.endTime != null).toList();
    final untimedStops = day.stops.where((s) => s.startTime == null || s.endTime == null).toList();

    return SingleChildScrollView(
      physics: const BouncingScrollPhysics(),
      padding: const EdgeInsets.only(bottom: 80),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          if (untimedStops.isNotEmpty) ...[
            const Padding(
              padding: EdgeInsets.fromLTRB(20, 16, 20, 8),
              child: Text(
                'NO TIME ASSIGNED',
                style: TextStyle(fontFamily: 'DM Sans', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: AppColors.warmMuted),
              ),
            ),
            ...untimedStops.map((s) => _UntimedStopRow(stop: s, onTap: () => onStopTap(s))),
            const Divider(height: 24, indent: 20, endIndent: 20),
          ],
          const Padding(
            padding: EdgeInsets.fromLTRB(20, 8, 20, 8),
            child: Text(
              'DAILY TIMELINE',
              style: TextStyle(fontFamily: 'DM Sans', fontSize: 10, fontWeight: FontWeight.w700, letterSpacing: 1.4, color: AppColors.warmMuted),
            ),
          ),
          if (timedStops.isEmpty)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(32),
                child: Text(
                  'Add start & end times to stops\nto see them in the timeline.',
                  style: TextStyle(fontFamily: 'DM Sans', fontSize: 13, color: AppColors.muted),
                  textAlign: TextAlign.center,
                ),
              ),
            )
          else
            SingleChildScrollView(
              scrollDirection: Axis.horizontal,
              physics: const BouncingScrollPhysics(),
              padding: const EdgeInsets.only(left: 20, right: 20, bottom: 12),
              child: _buildTimeline(timedStops),
            ),
        ],
      ),
    );
  }

  Widget _buildTimeline(List<ItineraryStop> stops) {
    const totalHours = 24;
    const totalWidth = totalHours * _hourWidth;

    return SizedBox(
      width: totalWidth,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Hour header
          SizedBox(
            height: _headerHeight,
            child: Row(
              children: List.generate(totalHours, (h) {
                return SizedBox(
                  width: _hourWidth,
                  child: Text(
                    h == 0 ? '12am' : h < 12 ? '${h}am' : h == 12 ? '12pm' : '${h - 12}pm',
                    style: const TextStyle(fontFamily: 'DM Sans', fontSize: 10, color: AppColors.muted),
                  ),
                );
              }),
            ),
          ),

          // Timeline track
          SizedBox(
            height: _rowHeight,
            child: Stack(
              children: [
                // Hour grid lines
                Row(
                  children: List.generate(
                    totalHours,
                    (h) => Container(
                      width: _hourWidth,
                      decoration: const BoxDecoration(
                        border: Border(left: BorderSide(color: AppColors.dividerLight, width: 0.5)),
                      ),
                    ),
                  ),
                ),
                // Stop blocks
                ...stops.map((s) => _buildBlock(s)),
                // Current time indicator
                _CurrentTimeIndicator(totalWidth: totalWidth, rowHeight: _rowHeight),
              ],
            ),
          ),

          // Legend
          const SizedBox(height: 12),
          Wrap(
            spacing: 12,
            runSpacing: 6,
            children: StopType.values.map((t) => Row(
              mainAxisSize: MainAxisSize.min,
              children: [
                Container(width: 10, height: 10, decoration: BoxDecoration(color: t.color, borderRadius: BorderRadius.circular(3))),
                const SizedBox(width: 4),
                Text(t.label, style: const TextStyle(fontFamily: 'DM Sans', fontSize: 10, color: AppColors.muted)),
              ],
            )).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildBlock(ItineraryStop stop) {
    final start = stop.startTime!;
    final end = stop.endTime!;
    final startMin = start.hour * 60 + start.minute;
    final endMin = end.hour * 60 + end.minute;
    final durMin = (endMin - startMin).clamp(15, 24 * 60).toDouble();

    final left = (startMin / 60.0) * _hourWidth;
    final width = (durMin / 60.0) * _hourWidth;

    return Positioned(
      left: left,
      top: 4,
      width: width,
      height: _rowHeight - 8,
      child: GestureDetector(
        onTap: () => onStopTap(stop),
        child: Container(
          padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
          decoration: BoxDecoration(
            color: stop.type.color,
            borderRadius: BorderRadius.circular(8),
            boxShadow: [BoxShadow(color: stop.type.color.withValues(alpha: 0.35), blurRadius: 4, offset: const Offset(0, 2))],
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                stop.title,
                style: const TextStyle(fontFamily: 'DM Sans', fontSize: 10, fontWeight: FontWeight.w700, color: Colors.white),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
              ),
              if (width > 60)
                Text(
                  stop.duration,
                  style: TextStyle(fontFamily: 'DM Sans', fontSize: 9, color: Colors.white.withValues(alpha: 0.8)),
                  maxLines: 1,
                ),
            ],
          ),
        ),
      ),
    );
  }
}

class _UntimedStopRow extends StatelessWidget {
  final ItineraryStop stop;
  final VoidCallback onTap;

  const _UntimedStopRow({required this.stop, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        margin: const EdgeInsets.symmetric(horizontal: 20, vertical: 4),
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(12),
          border: Border.all(color: stop.type.color.withValues(alpha: 0.3)),
        ),
        child: Row(
          children: [
            Icon(stop.type.icon, size: 16, color: stop.type.color),
            const SizedBox(width: 10),
            Expanded(
              child: Text(stop.title, style: const TextStyle(fontFamily: 'DM Sans', fontSize: 13, fontWeight: FontWeight.w600, color: AppColors.deepEarth)),
            ),
            const Icon(Icons.schedule_rounded, size: 14, color: AppColors.muted),
            const SizedBox(width: 4),
            const Text('No time', style: TextStyle(fontFamily: 'DM Sans', fontSize: 11, color: AppColors.muted)),
          ],
        ),
      ),
    );
  }
}

/// Animated vertical line marking the current time of day.
class _CurrentTimeIndicator extends StatelessWidget {
  final double totalWidth;
  final double rowHeight;

  const _CurrentTimeIndicator({required this.totalWidth, required this.rowHeight});

  @override
  Widget build(BuildContext context) {
    final now = TimeOfDay.now();
    final minuteOfDay = now.hour * 60 + now.minute;
    final left = (minuteOfDay / (24 * 60.0)) * totalWidth;

    return Positioned(
      left: left - 1,
      top: 0,
      bottom: 0,
      child: Container(
        width: 2,
        decoration: BoxDecoration(
          color: AppColors.primary,
          borderRadius: BorderRadius.circular(1),
          boxShadow: [BoxShadow(color: AppColors.primary.withValues(alpha: 0.4), blurRadius: 4)],
        ),
        child: Align(
          alignment: Alignment.topCenter,
          child: Container(
            width: 8,
            height: 8,
            decoration: const BoxDecoration(color: AppColors.primary, shape: BoxShape.circle),
          ),
        ),
      ),
    );
  }
}
