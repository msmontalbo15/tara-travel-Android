import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import '../../../core/theme/app_colors.dart';
import '../../../core/widgets/inputs/app_text_field.dart';
import '../models/new_trip_model.dart';
import '../widgets/step_indicator.dart';

class DetailsStep extends StatefulWidget {
  final NewTripModel trip;
  final VoidCallback onNext;
  final VoidCallback onCancel;

  const DetailsStep({
    super.key,
    required this.trip,
    required this.onNext,
    required this.onCancel,
  });

  @override
  State<DetailsStep> createState() => _DetailsStepState();
}

class _DetailsStepState extends State<DetailsStep> {
  late TextEditingController _nameController;
  late TextEditingController _destController;
  final _formKey = GlobalKey<FormState>();

  String? _nameError;
  String? _destError;
  String? _dateError;

  List<String> _placePredictions = [];
  bool _isLoadingPlaces = false;

  static const _tripTypes = [
    ('Beach', '🏖️'),
    ('City', '🏙️'),
    ('Adventure', '🏕️'),
    ('Nature', '🌿'),
    ('Cultural', '🏛️'),
  ];

  static const _coverColors = [
    0xFFD85A30, // primary
    0xFF2C1A14, // deepEarth
    0xFF10B981, // green
    0xFF3B82F6, // blue
    0xFF8B5CF6, // purple
    0xFFF59E0B, // amber
  ];

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.trip.tripName);
    _destController = TextEditingController(text: widget.trip.destination);
    
    // Default cover color
    if (widget.trip.coverColor == null) {
      widget.trip.coverColor = _coverColors[0];
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _destController.dispose();
    super.dispose();
  }

  bool _validate() {
    bool ok = true;
    setState(() {
      _nameError = _nameController.text.trim().isEmpty
          ? 'Please enter a trip name'
          : null;
      _destError = _destController.text.trim().isEmpty
          ? 'Please enter a destination'
          : null;
      _dateError = widget.trip.fromDate == null || widget.trip.toDate == null
          ? 'Please select travel dates'
          : (widget.trip.toDate!.isBefore(widget.trip.fromDate!)
              ? 'End date must be after start date'
              : null);
    });
    if (_nameError != null || _destError != null || _dateError != null) {
      ok = false;
    }
    return ok;
  }

  void _onContinue() {
    // Validate first — only commit to the draft if inputs are valid
    widget.trip.tripName = _nameController.text.trim();
    widget.trip.destination = _destController.text.trim();
    if (_validate()) widget.onNext();
  }

  Future<void> _fetchPlaces(String query) async {
    if (query.isEmpty) {
      setState(() => _placePredictions = []);
      return;
    }
    
    setState(() => _isLoadingPlaces = true);
    
    final apiKey = dotenv.env['EXPO_PUBLIC_GOOGLE_MAPS_API_KEY'] ?? dotenv.env['GOOGLE_MAPS_API_KEY'];
    
    if (apiKey == null || apiKey.isEmpty) {
      // Fallback to nominatim if no API key
      try {
        final uri = Uri.parse('https://nominatim.openstreetmap.org/search?q=${Uri.encodeComponent(query)}&format=json&limit=5');
        final res = await http.get(uri);
        if (res.statusCode == 200) {
          final List data = json.decode(res.body);
          setState(() {
            _placePredictions = data.map((e) => e['display_name'] as String).toList();
          });
        }
      } catch (_) {}
    } else {
      // Google Places
      try {
        final uri = Uri.parse('https://maps.googleapis.com/maps/api/place/autocomplete/json?input=${Uri.encodeComponent(query)}&key=$apiKey');
        final res = await http.get(uri);
        if (res.statusCode == 200) {
          final data = json.decode(res.body);
          if (data['status'] == 'OK') {
            setState(() {
              _placePredictions = (data['predictions'] as List)
                  .map((e) => e['description'] as String)
                  .toList();
            });
          }
        }
      } catch (_) {}
    }
    
    setState(() => _isLoadingPlaces = false);
  }

  Future<void> _selectDateRange() async {
    final initialDateRange = (widget.trip.fromDate != null && widget.trip.toDate != null) 
      ? DateTimeRange(start: widget.trip.fromDate!, end: widget.trip.toDate!)
      : null;

    final picked = await showDateRangePicker(
      context: context,
      firstDate: DateTime.now(),
      lastDate: DateTime.now().add(const Duration(days: 365 * 5)),
      initialDateRange: initialDateRange,
      builder: (context, child) {
        return Theme(
          data: Theme.of(context).copyWith(
            colorScheme: const ColorScheme.light(
              primary: AppColors.primary,
              onPrimary: Colors.white,
              onSurface: AppColors.deepEarth,
            ),
          ),
          child: child!,
        );
      }
    );

    if (picked != null) {
      setState(() {
        widget.trip.fromDate = picked.start;
        widget.trip.toDate = picked.end;
        _dateError = null;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.white,
      body: SafeArea(
        child: Form(
          key: _formKey,
          child: Column(
            children: [
              // ── Header ──────────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 16, 20, 0),
                child: Row(
                  children: [
                    GestureDetector(
                      onTap: widget.onCancel,
                      child: const Text(
                        'Cancel',
                        style: TextStyle(
                          fontFamily: 'DM Sans',
                          fontSize: 15,
                          color: AppColors.primary,
                        ),
                      ),
                    ),
                    const Expanded(
                      child: Center(
                        child: Text(
                          'New trip',
                          style: TextStyle(
                            fontFamily: 'DM Sans',
                            fontSize: 16,
                            fontWeight: FontWeight.w700,
                            color: AppColors.textPrimary,
                          ),
                        ),
                      ),
                    ),
                    const SizedBox(width: 50),
                  ],
                ),
              ),
              const SizedBox(height: 20),

              // ── Step indicator ──────────────────────────────────────
              const Padding(
                padding: EdgeInsets.symmetric(horizontal: 20),
                child: StepIndicator(
                  currentStep: 1,
                  totalSteps: 3,
                  label: 'Trip details',
                ),
              ),
              const SizedBox(height: 24),

              // ── Form ────────────────────────────────────────────────
              Expanded(
                child: SingleChildScrollView(
                  padding: const EdgeInsets.symmetric(horizontal: 20),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Trip name
                      AppTextField(
                        label: 'Trip name',
                        controller: _nameController,
                        hint: 'e.g. Summer in Paris',
                        errorText: _nameError,
                        prefixIcon: Icons.luggage_rounded,
                        textCapitalization: TextCapitalization.words,
                        onChanged: (_) {
                          if (_nameError != null) setState(() => _nameError = null);
                          widget.trip.tripName = _nameController.text;
                        },
                        semanticsLabel: 'Trip name field',
                      ),
                      const SizedBox(height: 18),

                      // Destination
                      const Text(
                        'Destination',
                        style: TextStyle(
                          fontFamily: 'DM Sans',
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.deepEarth,
                        ),
                      ),
                      const SizedBox(height: 8),
                      Autocomplete<String>(
                        optionsBuilder: (TextEditingValue textEditingValue) {
                          if (textEditingValue.text == '') {
                            return const Iterable<String>.empty();
                          }
                          return _placePredictions;
                        },
                        onSelected: (String selection) {
                          _destController.text = selection;
                          widget.trip.destination = selection;
                          if (_destError != null) setState(() => _destError = null);
                        },
                        fieldViewBuilder: (context, textEditingController, focusNode, onFieldSubmitted) {
                          // keep them in sync
                          if (textEditingController.text != _destController.text && !focusNode.hasFocus) {
                            textEditingController.text = _destController.text;
                          }
                          
                          textEditingController.addListener(() {
                            if (focusNode.hasFocus) {
                              _destController.text = textEditingController.text;
                              widget.trip.destination = textEditingController.text;
                              if (_destError != null) setState(() => _destError = null);
                              _fetchPlaces(textEditingController.text);
                            }
                          });
                          
                          return TextField(
                            controller: textEditingController,
                            focusNode: focusNode,
                            style: const TextStyle(fontFamily: 'DM Sans', fontSize: 15, color: AppColors.textPrimary),
                            decoration: InputDecoration(
                              hintText: 'e.g. Paris, France',
                              hintStyle: const TextStyle(fontFamily: 'DM Sans', fontSize: 15, color: AppColors.muted),
                              errorText: _destError,
                              prefixIcon: const Icon(Icons.location_on_rounded, color: AppColors.textSecondary, size: 20),
                              suffixIcon: _isLoadingPlaces 
                                  ? Container(
                                      width: 16, height: 16,
                                      margin: const EdgeInsets.all(14),
                                      child: const CircularProgressIndicator(strokeWidth: 2),
                                    ) 
                                  : null,
                              filled: true,
                              fillColor: AppColors.surfaceLight,
                              border: OutlineInputBorder(
                                borderRadius: BorderRadius.circular(16),
                                borderSide: BorderSide.none,
                              ),
                              contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                            ),
                          );
                        },
                        optionsViewBuilder: (context, onSelected, options) {
                          return Align(
                            alignment: Alignment.topLeft,
                            child: Material(
                              elevation: 4.0,
                              borderRadius: BorderRadius.circular(16),
                              child: Container(
                                width: MediaQuery.of(context).size.width - 40,
                                decoration: BoxDecoration(
                                  color: Colors.white,
                                  borderRadius: BorderRadius.circular(16),
                                ),
                                child: ListView.builder(
                                  padding: EdgeInsets.zero,
                                  shrinkWrap: true,
                                  itemCount: options.length,
                                  itemBuilder: (BuildContext context, int index) {
                                    final option = options.elementAt(index);
                                    return ListTile(
                                      title: Text(option, style: const TextStyle(fontFamily: 'DM Sans')),
                                      onTap: () => onSelected(option),
                                    );
                                  },
                                ),
                              ),
                            ),
                          );
                        },
                      ),
                      const SizedBox(height: 18),

                      // Travel dates — Unified Date Range Picker
                      const Text(
                        'Travel dates',
                        style: TextStyle(
                          fontFamily: 'DM Sans',
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.deepEarth,
                        ),
                      ),
                      const SizedBox(height: 8),
                      GestureDetector(
                        onTap: _selectDateRange,
                        child: Container(
                          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 16),
                          decoration: BoxDecoration(
                            color: AppColors.surfaceLight,
                            borderRadius: BorderRadius.circular(16),
                            border: Border.all(
                              color: _dateError != null ? AppColors.red : Colors.transparent,
                            ),
                          ),
                          child: Row(
                            children: [
                              const Icon(Icons.calendar_month_rounded, color: AppColors.textSecondary, size: 20),
                              const SizedBox(width: 12),
                              Text(
                                (widget.trip.fromDate != null && widget.trip.toDate != null)
                                    ? '${widget.trip.fromDate!.month}/${widget.trip.fromDate!.day}/${widget.trip.fromDate!.year} - ${widget.trip.toDate!.month}/${widget.trip.toDate!.day}/${widget.trip.toDate!.year}'
                                    : 'Select date range',
                                style: TextStyle(
                                  fontFamily: 'DM Sans',
                                  fontSize: 15,
                                  color: (widget.trip.fromDate != null && widget.trip.toDate != null) 
                                      ? AppColors.textPrimary 
                                      : AppColors.muted,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                      if (_dateError != null) ...[
                        const SizedBox(height: 6),
                        Padding(
                          padding: const EdgeInsets.only(left: 4),
                          child: Text(
                            _dateError!,
                            style: const TextStyle(
                              fontFamily: 'DM Sans',
                              fontSize: 12,
                              color: AppColors.red,
                            ),
                          ),
                        ),
                      ],
                      const SizedBox(height: 22),
                      
                      // Trip Cover Color selector
                      const Text(
                        'Trip Cover Color',
                        style: TextStyle(
                          fontFamily: 'DM Sans',
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.deepEarth,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Row(
                        children: _coverColors.map((colorValue) {
                          final isSelected = widget.trip.coverColor == colorValue;
                          return GestureDetector(
                            onTap: () {
                              setState(() => widget.trip.coverColor = colorValue);
                            },
                            child: Container(
                              margin: const EdgeInsets.only(right: 12),
                              width: 40,
                              height: 40,
                              decoration: BoxDecoration(
                                color: Color(colorValue),
                                shape: BoxShape.circle,
                                border: isSelected ? Border.all(color: AppColors.textPrimary, width: 3) : null,
                              ),
                              child: isSelected 
                                  ? const Icon(Icons.check, color: Colors.white, size: 20)
                                  : null,
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 22),

                      // Trip type chips
                      const Text(
                        'Trip type',
                        style: TextStyle(
                          fontFamily: 'DM Sans',
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.deepEarth,
                        ),
                      ),
                      const SizedBox(height: 10),
                      Wrap(
                        spacing: 8,
                        runSpacing: 8,
                        children: _tripTypes.map((entry) {
                          final type  = entry.$1;
                          final emoji = entry.$2;
                          final sel   = widget.trip.tripType == type;
                          return GestureDetector(
                            onTap: () => setState(() => widget.trip.tripType = type),
                            child: AnimatedContainer(
                              duration: const Duration(milliseconds: 180),
                              padding: const EdgeInsets.symmetric(
                                  horizontal: 14, vertical: 9),
                              decoration: BoxDecoration(
                                color: sel ? AppColors.primary : Colors.white,
                                border: Border.all(
                                  color: sel ? AppColors.primary : AppColors.cardBorder,
                                  width: sel ? 1.5 : 0.8,
                                ),
                                borderRadius: BorderRadius.circular(20),
                                boxShadow: sel
                                    ? [BoxShadow(
                                        color: AppColors.primary.withValues(alpha: 0.18),
                                        blurRadius: 8,
                                        offset: const Offset(0, 3),
                                      )]
                                    : [],
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Text(emoji, style: const TextStyle(fontSize: 15)),
                                  const SizedBox(width: 6),
                                  Text(
                                    type,
                                    style: TextStyle(
                                      fontFamily: 'DM Sans',
                                      fontSize: 13,
                                      fontWeight: FontWeight.w600,
                                      color: sel ? Colors.white : AppColors.textSecondary,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                      const SizedBox(height: 22),

                      // Travelers
                      const Text(
                        'Travelers',
                        style: TextStyle(
                          fontFamily: 'DM Sans',
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppColors.deepEarth,
                        ),
                      ),
                      const SizedBox(height: 10),
                      _travelersRow(),
                      const SizedBox(height: 32),
                    ],
                  ),
                ),
              ),

              // ── CTA ─────────────────────────────────────────────────
              Padding(
                padding: const EdgeInsets.fromLTRB(20, 0, 20, 24),
                child: SizedBox(
                  width: double.infinity,
                  height: 52,
                  child: ElevatedButton(
                    onPressed: _onContinue,
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.primary,
                      foregroundColor: Colors.white,
                      elevation: 0,
                      shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(14)),
                    ),
                    child: const Text(
                      'Continue — Budget setup',
                      style: TextStyle(
                        fontFamily: 'DM Sans',
                        fontSize: 15,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _travelersRow() {
    return Row(
      children: [
        ...widget.trip.travelers.map((t) => _avatar(t.initials, t.color)),
        const SizedBox(width: 8),
        GestureDetector(
          onTap: () {
            setState(() {
              if (widget.trip.travelers.length < 5) {
                widget.trip.travelers.add(
                  TravelerModel(
                    name: 'Traveler ${widget.trip.travelers.length + 1}',
                    initials: 'T${widget.trip.travelers.length + 1}',
                    color: [0xFFEAB308, 0xFF3B82F6, 0xFF10B981, 0xFF8B5CF6]
                        [widget.trip.travelers.length % 4],
                  ),
                );
              }
            });
          },
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            decoration: BoxDecoration(
              border: Border.all(color: AppColors.primary),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Row(
              children: [
                Icon(Icons.add, size: 14, color: AppColors.primary),
                SizedBox(width: 4),
                Text(
                  'Add',
                  style: TextStyle(
                    fontFamily: 'DM Sans',
                    fontSize: 13,
                    fontWeight: FontWeight.w600,
                    color: AppColors.primary,
                  ),
                ),
              ],
            ),
          ),
        ),
      ],
    );
  }

  Widget _avatar(String initials, int color) {
    return Container(
      margin: const EdgeInsets.only(right: 6),
      width: 34,
      height: 34,
      decoration: BoxDecoration(
        color: Color(color),
        shape: BoxShape.circle,
        border: Border.all(color: Colors.white, width: 2),
      ),
      child: Center(
        child: Text(
          initials,
          style: const TextStyle(
            fontFamily: 'DM Sans',
            fontSize: 12,
            fontWeight: FontWeight.w700,
            color: Colors.white,
          ),
        ),
      ),
    );
  }
}
