import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:intl/intl.dart';
import '../../core/theme/app_colors.dart';
import '../../core/providers/selected_trip_provider.dart';
import '../../core/providers/expense_provider.dart';
import '../../core/providers/packing_provider.dart';
import '../../core/providers/itinerary_provider.dart';
import '../../core/models/trip_model.dart';
import '../../core/models/expense_model.dart';
import '../../core/widgets/buttons/app_back_button.dart';

// ─────────────────────────────────────────────────────────────────────────────
// TripDetailScreen — dashboard UI (section-card layout)
// ─────────────────────────────────────────────────────────────────────────────

class TripDetailScreen extends ConsumerWidget {
  const TripDetailScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final tripAsync = ref.watch(selectedTripProvider);

    return tripAsync.when(
      data: (trip) {
        if (trip == null) {
          return const Scaffold(
            backgroundColor: AppColors.surfaceLight,
            body: Center(child: Text('Trip not found')),
          );
        }
        return _TripDashboard(trip: trip);
      },
      loading: () => const Scaffold(
        backgroundColor: AppColors.surfaceLight,
        body: Center(
          child: CircularProgressIndicator(color: AppColors.primary),
        ),
      ),
      error: (e, _) => Scaffold(
        backgroundColor: AppColors.surfaceLight,
        body: Center(child: Text('Error: $e')),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────

class _TripDashboard extends ConsumerStatefulWidget {
  final TripModel trip;
  const _TripDashboard({required this.trip});

  @override
  ConsumerState<_TripDashboard> createState() => _TripDashboardState();
}

class _TripDashboardState extends ConsumerState<_TripDashboard> {
  int _activeNavIndex = -1;

  /// Parse a CSS hex string like '#D85A30' or '0xFFD85A30'
  Color _parseCoverColor(String? raw) {
    if (raw == null || raw.isEmpty) return const Color(0xFF2C1A14);
    final s = raw.replaceAll('#', '').replaceAll('0x', '').replaceAll('0X', '');
    if (s.length == 6) return Color(int.parse('FF$s', radix: 16));
    if (s.length == 8) return Color(int.parse(s, radix: 16));
    return const Color(0xFF2C1A14);
  }

  static const _navItems = [
    _FloatingNavItem(
      icon: Icons.calendar_month_rounded,
      label: 'Itinerary',
      color: Color(0xFF5B8DEF),
      route: '/itinerary',
    ),
    _FloatingNavItem(
      icon: Icons.luggage_rounded,
      label: 'Packing',
      color: Color(0xFFC07C2A),
      route: '/packing',
    ),
    _FloatingNavItem(
      icon: Icons.group_rounded,
      label: 'Members',
      color: Color(0xFF4CAF50),
      route: '/members',
    ),
    _FloatingNavItem(
      icon: Icons.attach_money_rounded,
      label: 'Expenses',
      color: Color(0xFF43A047),
      route: '/budget',
    ),
    _FloatingNavItem(
      icon: Icons.chat_bubble_outline_rounded,
      label: 'Chat',
      color: Color(0xFF7E57C2),
      route: '/chat',
    ),
  ];

  @override
  Widget build(BuildContext context) {
    final trip = widget.trip;
    final coverColor = _parseCoverColor(trip.coverColor);

    // ── Expenses ─────────────────────────────────────────────────
    final expensesAsync = ref.watch(expenseProvider(trip.id));
    final expenses = expensesAsync.asData?.value ?? trip.expenses;

    final totalSpent = expenses
        .where((e) => e.status == ExpenseStatus.approved)
        .fold<double>(0, (s, e) => s + e.amount);
    final totalPending = expenses
        .where((e) => e.status == ExpenseStatus.pending)
        .fold<double>(0, (s, e) => s + e.amount);
    final remaining = trip.totalBudget - totalSpent;
    final budgetPct =
        trip.totalBudget > 0 ? (totalSpent / trip.totalBudget).clamp(0.0, 1.0) : 0.0;

    // ── Packing ──────────────────────────────────────────────────
    final packingProviderInst = ref.watch(packingProvider(trip.id));
    final packingState = ref.watch(packingProviderInst);
    final packedCount = packingState.packedItems;
    final totalPacking = packingState.totalItems;

    // ── Itinerary ────────────────────────────────────────────────
    final itineraryProviderInst = ref.watch(itineraryProvider(trip.id));
    final itineraryAsync = ref.watch(itineraryProviderInst);
    final itineraryDayCount = itineraryAsync.asData?.value.days.length ?? 0;

    final nights = trip.toDate.difference(trip.fromDate).inDays;
    final now = DateTime.now();
    final isActive = now.isAfter(trip.fromDate) && now.isBefore(trip.toDate);

    // ── Section definitions (vertical list) ──────────────────────
    final sections = [
      _SectionItem(
        icon: Icons.calendar_month_rounded,
        label: 'Itinerary',
        subtitle: '$itineraryDayCount days planned',
        color: const Color(0xFF185FA5),
        route: '/itinerary',
      ),
      _SectionItem(
        icon: Icons.luggage_rounded,
        label: 'Packing',
        subtitle: '$packedCount / $totalPacking items packed',
        color: const Color(0xFF854F0B),
        route: '/packing',
      ),
      _SectionItem(
        icon: Icons.group_rounded,
        label: 'Members',
        subtitle: '${trip.members.length} people',
        color: const Color(0xFF3B6D11),
        route: '/members',
      ),
      _SectionItem(
        icon: Icons.account_balance_wallet_rounded,
        label: 'Budget & Expenses',
        subtitle: '₱${_fmt(totalSpent)} spent',
        color: AppColors.primary,
        route: '/budget',
      ),
      const _SectionItem(
        icon: Icons.chat_bubble_rounded,
        label: 'Chat & Polls',
        subtitle: 'Group chat',
        color: Color(0xFF4A2C7A),
        route: '/chat',
      ),
    ];

    return Scaffold(
      backgroundColor: const Color(0xFFF2F2F7),
      body: Stack(
        children: [
          CustomScrollView(
            physics: const BouncingScrollPhysics(),
            slivers: [
              // ── Hero ────────────────────────────────────────────────
              SliverToBoxAdapter(
                child: _HeroHeader(
                  trip: trip,
                  coverColor: coverColor,
                  nights: nights,
                  isActive: isActive,
                ),
              ),

              // ── Body ────────────────────────────────────────────────
              SliverPadding(
                padding: const EdgeInsets.fromLTRB(16, 16, 16, 32),
                sliver: SliverList(
                  delegate: SliverChildListDelegate([
                    // Stats row
                    _StatsRow(trip: trip, nights: nights),
                    const SizedBox(height: 12),

                    // Budget bar
                    if (trip.totalBudget > 0) ...[
                      _BudgetCard(
                        totalSpent: totalSpent,
                        totalPending: totalPending,
                        remaining: remaining,
                        budget: trip.totalBudget,
                        budgetPct: budgetPct,
                        onTap: () => Navigator.pushNamed(context, '/budget'),
                      ),
                      const SizedBox(height: 12),
                    ],

                    // Section links
                    _SectionLinks(sections: sections),
                    const SizedBox(height: 12),

                    // Navigate CTA — active trips only
                    if (isActive) ...[
                      _NavButton(
                        onTap: () => Navigator.pushNamed(context, '/navigation'),
                      ),
                      const SizedBox(height: 12),
                    ],

                    // Invite code
                    if (trip.inviteCode.isNotEmpty)
                      _InviteCard(inviteCode: trip.inviteCode),

                    // Bottom clearance for floating nav
                    const SizedBox(height: 80),
                  ]),
                ),
              ),
            ],
          ),

          // ── Floating bottom nav ──────────────────────────────────
          Positioned(
            left: 20,
            right: 20,
            bottom: MediaQuery.of(context).padding.bottom + 16,
            child: _FloatingTripNav(
              items: _navItems,
              activeIndex: _activeNavIndex,
              onTap: (index) {
                setState(() => _activeNavIndex = index);
                Navigator.pushNamed(context, _navItems[index].route).then((_) {
                  if (mounted) setState(() => _activeNavIndex = -1);
                });
              },
            ),
          ),
        ],
      ),
    );
  }

  static String _fmt(double v) =>
      NumberFormat('#,##0', 'en_PH').format(v.toInt());
}


// ─────────────────────────────────────────────────────────────────────────────
// Hero Header
// ─────────────────────────────────────────────────────────────────────────────

class _HeroHeader extends StatelessWidget {
  final TripModel trip;
  final Color coverColor;
  final int nights;
  final bool isActive;

  const _HeroHeader({
    required this.trip,
    required this.coverColor,
    required this.nights,
    required this.isActive,
  });

  @override
  Widget build(BuildContext context) {
    final topPad = MediaQuery.of(context).padding.top;

    return Container(
      color: coverColor,
      child: Padding(
        padding: EdgeInsets.fromLTRB(20, topPad + 12, 20, 24),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const AppBackButton(),
            const SizedBox(height: 20),

            _StatusBadge(isActive: isActive, isArchived: trip.isArchived),
            const SizedBox(height: 10),

            Text(
              trip.name,
              style: const TextStyle(
                fontFamily: 'Playfair Display',
                fontSize: 30,
                fontWeight: FontWeight.w700,
                color: Colors.white,
                height: 1.15,
              ),
            ),
            const SizedBox(height: 6),

            Row(
              children: [
                Icon(Icons.place_rounded,
                    color: Colors.white.withValues(alpha: 0.55), size: 14),
                const SizedBox(width: 4),
                Text(
                  trip.destination,
                  style: TextStyle(
                    fontFamily: 'DM Sans',
                    fontSize: 13,
                    color: Colors.white.withValues(alpha: 0.55),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),

            Text(
              '${DateFormat('MMM d').format(trip.fromDate)}–'
              '${DateFormat('MMM d, yyyy').format(trip.toDate)} · $nights nights',
              style: TextStyle(
                fontFamily: 'DM Sans',
                fontSize: 12,
                color: Colors.white.withValues(alpha: 0.30),
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Status Badge
// ─────────────────────────────────────────────────────────────────────────────

class _StatusBadge extends StatelessWidget {
  final bool isActive;
  final bool isArchived;
  const _StatusBadge({required this.isActive, required this.isArchived});

  @override
  Widget build(BuildContext context) {
    final label = isActive ? 'Active' : isArchived ? 'Completed' : 'Planning';
    final bg =
        isActive ? AppColors.primary : Colors.white.withValues(alpha: 0.2);

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
      decoration: BoxDecoration(
        color: bg,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Text(
        label,
        style: const TextStyle(
          fontFamily: 'DM Sans',
          fontSize: 11,
          fontWeight: FontWeight.w700,
          color: Colors.white,
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Stats Row  (Nights / Budget / People)
// ─────────────────────────────────────────────────────────────────────────────

class _StatsRow extends StatelessWidget {
  final TripModel trip;
  final int nights;
  const _StatsRow({required this.trip, required this.nights});

  @override
  Widget build(BuildContext context) {
    final budget = trip.totalBudget;
    final budgetLabel = budget >= 1000
        ? '₱${(budget / 1000).toStringAsFixed(0)}k'
        : '₱${budget.toInt()}';

    return Row(
      children: [
        Expanded(child: _StatCell(label: 'Nights', value: '$nights')),
        const SizedBox(width: 8),
        Expanded(child: _StatCell(label: 'Budget', value: budgetLabel)),
        const SizedBox(width: 8),
        Expanded(child: _StatCell(label: 'People', value: '${trip.members.length}')),
      ],
    );
  }
}

class _StatCell extends StatelessWidget {
  final String label;
  final String value;
  const _StatCell({required this.label, required this.value});

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(vertical: 14),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: const Color(0xFFE5E5EA)),
      ),
      child: Column(
        children: [
          Text(
            label.toUpperCase(),
            style: const TextStyle(
              fontFamily: 'DM Sans',
              fontSize: 9,
              fontWeight: FontWeight.w600,
              color: Color(0xFF8E8E93),
              letterSpacing: 0.8,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            value,
            style: const TextStyle(
              fontFamily: 'DM Sans',
              fontSize: 20,
              fontWeight: FontWeight.w800,
              color: Color(0xFF1A1A1A),
            ),
          ),
        ],
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Budget Card
// ─────────────────────────────────────────────────────────────────────────────

class _BudgetCard extends StatelessWidget {
  final double totalSpent;
  final double totalPending;
  final double remaining;
  final double budget;
  final double budgetPct;
  final VoidCallback onTap;

  const _BudgetCard({
    required this.totalSpent,
    required this.totalPending,
    required this.remaining,
    required this.budget,
    required this.budgetPct,
    required this.onTap,
  });

  Color get _barColor {
    if (budgetPct >= 0.9) return const Color(0xFFA32D2D);
    if (budgetPct > 0.7) return const Color(0xFFE09A30);
    return AppColors.primary;
  }

  Color get _pctColor =>
      budgetPct > 0.9 ? const Color(0xFFA32D2D) : AppColors.primary;

  static String _fmt(double v) =>
      NumberFormat('#,##0', 'en_PH').format(v.toInt());

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.all(16),
        decoration: BoxDecoration(
          color: Colors.white,
          borderRadius: BorderRadius.circular(18),
          border: Border.all(color: const Color(0xFFE5E5EA)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Header
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                const Text(
                  'Budget',
                  style: TextStyle(
                    fontFamily: 'DM Sans',
                    fontSize: 14,
                    fontWeight: FontWeight.w700,
                    color: Color(0xFF1A1A1A),
                  ),
                ),
                Text(
                  '${(budgetPct * 100).round()}% used',
                  style: TextStyle(
                    fontFamily: 'DM Sans',
                    fontSize: 13,
                    fontWeight: FontWeight.w700,
                    color: _pctColor,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 10),

            // Progress bar
            ClipRRect(
              borderRadius: BorderRadius.circular(6),
              child: TweenAnimationBuilder<double>(
                tween: Tween(begin: 0, end: budgetPct),
                duration: const Duration(milliseconds: 700),
                curve: Curves.easeOut,
                builder: (_, val, __) => LinearProgressIndicator(
                  value: val,
                  minHeight: 10,
                  backgroundColor: const Color(0xFFF2F2F7),
                  valueColor: AlwaysStoppedAnimation<Color>(_barColor),
                ),
              ),
            ),
            const SizedBox(height: 12),

            // Spent / Pending / Remaining
            Row(
              children: [
                Expanded(
                  child: _BudgetStat(
                    label: 'Spent',
                    value: '₱${_fmt(totalSpent)}',
                    valueColor: const Color(0xFF1A1A1A),
                  ),
                ),
                Expanded(
                  child: _BudgetStat(
                    label: 'Pending',
                    value: '₱${_fmt(totalPending)}',
                    valueColor: const Color(0xFF854F0B),
                    align: CrossAxisAlignment.center,
                  ),
                ),
                Expanded(
                  child: _BudgetStat(
                    label: 'Remaining',
                    value:
                        '₱${_fmt(remaining.abs())}${remaining < 0 ? ' over' : ''}',
                    valueColor: remaining < 0
                        ? const Color(0xFFA32D2D)
                        : const Color(0xFF3B6D11),
                    align: CrossAxisAlignment.end,
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}

class _BudgetStat extends StatelessWidget {
  final String label;
  final String value;
  final Color valueColor;
  final CrossAxisAlignment align;

  const _BudgetStat({
    required this.label,
    required this.value,
    required this.valueColor,
    this.align = CrossAxisAlignment.start,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: align,
      children: [
        Text(label,
            style: const TextStyle(
                fontFamily: 'DM Sans',
                fontSize: 11,
                color: Color(0xFF8E8E93))),
        const SizedBox(height: 2),
        Text(value,
            style: TextStyle(
                fontFamily: 'DM Sans',
                fontSize: 13,
                fontWeight: FontWeight.w700,
                color: valueColor)),
      ],
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Floating Trip Navigation
// ─────────────────────────────────────────────────────────────────────────────

class _FloatingNavItem {
  final IconData icon;
  final String label;
  final Color color;
  final String route;

  const _FloatingNavItem({
    required this.icon,
    required this.label,
    required this.color,
    required this.route,
  });
}

class _FloatingTripNav extends StatelessWidget {
  final List<_FloatingNavItem> items;
  final int activeIndex;
  final ValueChanged<int> onTap;

  const _FloatingTripNav({
    required this.items,
    required this.activeIndex,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 10),
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(28),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.10),
            blurRadius: 24,
            offset: const Offset(0, 8),
          ),
          BoxShadow(
            color: Colors.black.withValues(alpha: 0.04),
            blurRadius: 6,
            offset: const Offset(0, 2),
          ),
        ],
        border: Border.all(
          color: const Color(0xFFE5E5EA).withValues(alpha: 0.6),
        ),
      ),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceAround,
        children: List.generate(items.length, (i) {
          final item = items[i];
          final isActive = i == activeIndex;
          return _FloatingNavItemWidget(
            icon: item.icon,
            label: item.label,
            iconColor: item.color,
            isActive: isActive,
            onTap: () => onTap(i),
          );
        }),
      ),
    );
  }
}

class _FloatingNavItemWidget extends StatelessWidget {
  final IconData icon;
  final String label;
  final Color iconColor;
  final bool isActive;
  final VoidCallback onTap;

  const _FloatingNavItemWidget({
    required this.icon,
    required this.label,
    required this.iconColor,
    required this.isActive,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      behavior: HitTestBehavior.opaque,
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 200),
        curve: Curves.easeOut,
        padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 4),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            AnimatedContainer(
              duration: const Duration(milliseconds: 200),
              curve: Curves.easeOut,
              width: 42,
              height: 42,
              decoration: BoxDecoration(
                color: isActive
                    ? AppColors.primary.withValues(alpha: 0.12)
                    : iconColor.withValues(alpha: 0.08),
                borderRadius: BorderRadius.circular(14),
                border: isActive
                    ? Border.all(
                        color: AppColors.primary.withValues(alpha: 0.25),
                        width: 1.5,
                      )
                    : null,
              ),
              child: Icon(
                icon,
                size: 20,
                color: isActive ? AppColors.primary : iconColor,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              label,
              style: TextStyle(
                fontFamily: 'DM Sans',
                fontSize: 10,
                fontWeight: isActive ? FontWeight.w700 : FontWeight.w500,
                color: isActive ? AppColors.primary : const Color(0xFF8E8E93),
                letterSpacing: 0.1,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Section Links (vertical list — retained for dashboard body)
// ─────────────────────────────────────────────────────────────────────────────

class _SectionItem {
  final IconData icon;
  final String label;
  final String subtitle;
  final Color color;
  final String route;

  const _SectionItem({
    required this.icon,
    required this.label,
    required this.subtitle,
    required this.color,
    required this.route,
  });
}

class _SectionLinks extends StatelessWidget {
  final List<_SectionItem> sections;

  const _SectionLinks({required this.sections});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: BoxDecoration(
        color: Colors.white,
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: const Color(0xFFE5E5EA)),
      ),
      child: Column(
        children: sections.asMap().entries.map((entry) {
          final isLast = entry.key == sections.length - 1;
          return _SectionRow(
            item: entry.value,
            showDivider: !isLast,
            onTap: () => Navigator.pushNamed(context, entry.value.route),
          );
        }).toList(),
      ),
    );
  }
}

class _SectionRow extends StatefulWidget {
  final _SectionItem item;
  final bool showDivider;
  final VoidCallback onTap;

  const _SectionRow({
    required this.item,
    required this.showDivider,
    required this.onTap,
  });

  @override
  State<_SectionRow> createState() => _SectionRowState();
}

class _SectionRowState extends State<_SectionRow> {
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: (_) => setState(() => _pressed = true),
      onTapUp: (_) {
        setState(() => _pressed = false);
        widget.onTap();
      },
      onTapCancel: () => setState(() => _pressed = false),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 80),
        color: _pressed ? const Color(0xFFF2F2F7) : Colors.transparent,
        child: Column(
          children: [
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
              child: Row(
                children: [
                  Container(
                    width: 40,
                    height: 40,
                    decoration: BoxDecoration(
                      color: widget.item.color.withValues(alpha: 0.12),
                      borderRadius: BorderRadius.circular(12),
                    ),
                    child: Icon(widget.item.icon,
                        size: 20, color: widget.item.color),
                  ),
                  const SizedBox(width: 14),
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(widget.item.label,
                            style: const TextStyle(
                              fontFamily: 'DM Sans',
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                              color: Color(0xFF1A1A1A),
                            )),
                        const SizedBox(height: 1),
                        Text(widget.item.subtitle,
                            style: const TextStyle(
                              fontFamily: 'DM Sans',
                              fontSize: 12,
                              color: Color(0xFF8E8E93),
                            )),
                      ],
                    ),
                  ),
                  const Icon(Icons.chevron_right_rounded,
                      size: 20, color: Color(0xFFC7C7CC)),
                ],
              ),
            ),
            if (widget.showDivider)
              const Divider(
                  height: 1,
                  thickness: 1,
                  indent: 70,
                  color: Color(0xFFE5E5EA)),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Navigation CTA
// ─────────────────────────────────────────────────────────────────────────────

class _NavButton extends StatelessWidget {
  final VoidCallback onTap;
  const _NavButton({required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        width: double.infinity,
        padding: const EdgeInsets.symmetric(vertical: 16),
        decoration: BoxDecoration(
          color: AppColors.primary,
          borderRadius: BorderRadius.circular(18),
          boxShadow: [
            BoxShadow(
              color: AppColors.primary.withValues(alpha: 0.35),
              blurRadius: 14,
              offset: const Offset(0, 5),
            ),
          ],
        ),
        child: const Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.navigation_rounded, color: Colors.white, size: 20),
            SizedBox(width: 8),
            Text(
              'Start Navigation',
              style: TextStyle(
                fontFamily: 'DM Sans',
                fontSize: 15,
                fontWeight: FontWeight.w700,
                color: Colors.white,
              ),
            ),
          ],
        ),
      ),
    );
  }
}

// ─────────────────────────────────────────────────────────────────────────────
// Invite Code Card
// ─────────────────────────────────────────────────────────────────────────────

class _InviteCard extends StatefulWidget {
  final String inviteCode;
  const _InviteCard({required this.inviteCode});

  @override
  State<_InviteCard> createState() => _InviteCardState();
}

class _InviteCardState extends State<_InviteCard> {
  bool _copied = false;

  void _copy() {
    Clipboard.setData(ClipboardData(text: widget.inviteCode));
    setState(() => _copied = true);
    Future.delayed(const Duration(seconds: 2), () {
      if (mounted) setState(() => _copied = false);
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: _copy,
      child: Container(
        padding: const EdgeInsets.all(18),
        decoration: BoxDecoration(
          color: const Color(0xFF2C1A14),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          children: [
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'INVITE CODE',
                    style: TextStyle(
                      fontFamily: 'DM Sans',
                      fontSize: 10,
                      fontWeight: FontWeight.w700,
                      color: Colors.white.withValues(alpha: 0.40),
                      letterSpacing: 1.5,
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    widget.inviteCode,
                    style: const TextStyle(
                      fontFamily: 'DM Sans',
                      fontSize: 26,
                      fontWeight: FontWeight.w800,
                      color: Colors.white,
                      letterSpacing: 4,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Tap to copy · Share with your squad',
                    style: TextStyle(
                      fontFamily: 'DM Sans',
                      fontSize: 11,
                      color: Colors.white.withValues(alpha: 0.30),
                    ),
                  ),
                ],
              ),
            ),
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 200),
              child: _copied
                  ? const Icon(Icons.check_circle_rounded,
                      key: ValueKey('check'),
                      color: AppColors.greenBright,
                      size: 24)
                  : Icon(Icons.copy_rounded,
                      key: const ValueKey('copy'),
                      color: Colors.white.withValues(alpha: 0.4),
                      size: 22),
            ),
          ],
        ),
      ),
    );
  }
}
